import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useAuth, type Role } from "@/lib/auth";
import { GraduationCap, LogOut, Bell, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useDB } from "@/lib/store";
import type { ReactNode } from "react";

interface NavItem { label: string; to: string; icon?: ReactNode }

export function AppLayout({ role, nav, children, title }: { role: Role; nav: NavItem[]; children: ReactNode; title: string }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: s => s.location.pathname });
  const [db] = useDB();
  const unread = db.notifications.filter(n => !n.read).length;

  const roleColor = {
    admin: "bg-primary",
    teacher: "bg-accent",
    student: "bg-success",
    parent: "bg-warning",
  }[role];

  return (
    <div className="min-h-screen flex bg-background">
      <aside className="w-64 border-r bg-card flex flex-col">
        <div className="p-5 border-b">
          <div className="flex items-center gap-2">
            <div className={`size-9 rounded-lg ${roleColor} flex items-center justify-center text-primary-foreground`}>
              <GraduationCap className="size-5" />
            </div>
            <div>
              <div className="font-bold text-sm">Noor Academy</div>
              <div className="text-xs text-muted-foreground capitalize">{role} Panel</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {nav.map(item => {
            const active = pathname === item.to;
            return (
              <Link key={item.to} to={item.to}
                className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-colors ${active ? "bg-primary text-primary-foreground" : "hover:bg-muted text-foreground"}`}>
                {item.icon}
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t">
          <Button variant="ghost" className="w-full justify-start" onClick={() => { logout(); navigate({ to: "/login" }); }}>
            <LogOut className="size-4 mr-2" /> Logout
          </Button>
        </div>
      </aside>
      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b bg-card px-6 flex items-center justify-between gap-4">
          <div>
            <h1 className="text-lg font-semibold">{title}</h1>
            <p className="text-xs text-muted-foreground">Welcome back, {user?.name}</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input placeholder="Search..." className="pl-9 w-64" />
            </div>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="size-5" />
              {unread > 0 && <Badge className="absolute -top-1 -right-1 size-5 p-0 flex items-center justify-center text-[10px]">{unread}</Badge>}
            </Button>
            <div className="size-9 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-semibold">
              {user?.name?.charAt(0)}
            </div>
          </div>
        </header>
        <div className="flex-1 p-6 overflow-y-auto">{children}</div>
      </main>
    </div>
  );
}