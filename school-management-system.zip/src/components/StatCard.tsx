import { Card } from "@/components/ui/card";
import type { LucideIcon } from "lucide-react";

export function StatCard({ label, value, icon: Icon, hint, color = "primary" }: {
  label: string; value: string | number; icon: LucideIcon; hint?: string;
  color?: "primary" | "accent" | "success" | "warning" | "destructive";
}) {
  const colorMap = {
    primary: "bg-primary/10 text-primary",
    accent: "bg-accent/10 text-accent",
    success: "bg-success/10 text-success",
    warning: "bg-warning/10 text-warning",
    destructive: "bg-destructive/10 text-destructive",
  };
  return (
    <Card className="p-5 flex items-start gap-4">
      <div className={`size-12 rounded-xl flex items-center justify-center ${colorMap[color]}`}>
        <Icon className="size-6" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="text-2xl font-bold tabular-nums">{value}</div>
        {hint && <div className="text-xs text-muted-foreground mt-0.5">{hint}</div>}
      </div>
    </Card>
  );
}