export type ID = string;
import { useEffect, useState, useCallback } from "react";

export interface Student { id: ID; rollNo: string; name: string; classId: ID; gender: "M"|"F"; dob: string; parentName: string; parentPhone: string; address: string; admissionDate: string; feeStatus: "paid"|"due"|"partial" }
export interface Teacher { id: ID; empId: string; name: string; subject: string; phone: string; email: string; salary: number; joiningDate: string }
export interface ClassRoom { id: ID; name: string; section: string; teacherId: ID; capacity: number }
export interface Subject { id: ID; name: string; code: string; classId: ID }
export interface FeeRecord { id: ID; studentId: ID; type: string; amount: number; dueDate: string; paidDate?: string; status: "paid"|"due"|"partial" }
export interface AttendanceRecord { id: ID; studentId: ID; date: string; status: "present"|"absent"|"leave"; method: "manual"|"qr"|"face" }
export interface ExamRecord { id: ID; name: string; type: string; classId: ID; date: string }
export interface MarkRecord { id: ID; studentId: ID; examId: ID; subjectId: ID; marks: number; total: number; grade: string; updatedAt: string }
export interface Homework { id: ID; classId: ID; subjectId: ID; title: string; description: string; dueDate: string; teacherId: ID }
export interface TimetableEntry { id: ID; classId: ID; day: string; period: number; subjectId: ID; teacherId: ID }
export interface LibraryBook { id: ID; title: string; author: string; isbn: string; copies: number; available: number }
export interface BookIssue { id: ID; bookId: ID; studentId: ID; issueDate: string; dueDate: string; returnDate?: string; fine: number }
export interface SalaryRecord { id: ID; teacherId: ID; month: string; amount: number; status: "paid"|"pending"; paidDate?: string }
export interface Transaction { id: ID; date: string; type: "income"|"expense"; category: string; description: string; amount: number }
export interface AuditLog { id: ID; timestamp: string; user: string; action: string; detail: string; ip: string }
export interface NotificationItem { id: ID; title: string; message: string; type: "info"|"success"|"warning"|"alert"; date: string; read: boolean; channel: "in-app"|"sms"|"email"|"whatsapp" }

export interface DB {
  students: Student[]; teachers: Teacher[]; classes: ClassRoom[]; subjects: Subject[];
  fees: FeeRecord[]; attendance: AttendanceRecord[]; exams: ExamRecord[]; marks: MarkRecord[];
  homework: Homework[]; timetable: TimetableEntry[]; books: LibraryBook[]; bookIssues: BookIssue[];
  salaries: SalaryRecord[]; transactions: Transaction[]; auditLogs: AuditLog[]; notifications: NotificationItem[];
}

const KEY = "sms_db_v1";

function uid(prefix = "id") { return `${prefix}-${Math.random().toString(36).slice(2, 9)}`; }

function seed(): DB {
  const classes: ClassRoom[] = [
    { id: "c-1", name: "Grade 9", section: "A", teacherId: "t-1", capacity: 35 },
    { id: "c-2", name: "Grade 10", section: "A", teacherId: "t-2", capacity: 35 },
    { id: "c-3", name: "Grade 11", section: "B", teacherId: "t-3", capacity: 30 },
  ];
  const teachers: Teacher[] = [
    { id: "t-1", empId: "EMP001", name: "Yusuf Karimi", subject: "Mathematics", phone: "+93700000001", email: "yusuf@school.edu", salary: 35000, joiningDate: "2020-03-15" },
    { id: "t-2", empId: "EMP002", name: "Fatima Noori", subject: "English", phone: "+93700000002", email: "fatima@school.edu", salary: 32000, joiningDate: "2021-07-01" },
    { id: "t-3", empId: "EMP003", name: "Hassan Rahimi", subject: "Physics", phone: "+93700000003", email: "hassan@school.edu", salary: 38000, joiningDate: "2019-08-20" },
    { id: "t-4", empId: "EMP004", name: "Sara Azimi", subject: "Chemistry", phone: "+93700000004", email: "sara@school.edu", salary: 34000, joiningDate: "2022-02-10" },
  ];
  const subjects: Subject[] = [
    { id: "sub-1", name: "Mathematics", code: "MATH", classId: "c-1" },
  ];
  const students: Student[] = [];
  const today = new Date();
  for (let i = 0; i < 24; i++) {
    students.push({
      id: i === 0 ? "s-1" : uid("s"),
      rollNo: String(100 + i),
      name: ["Bilal Ahmad","Sajid Khan","Ayesha Wali","Omar Faruq","Zainab Ali","Hassan Naseri","Maryam Sadat","Ali Reza","Hadia Karim","Yasmin Noor","Tariq Aslam","Nadia Habibi","Junaid Wahid","Layla Rashid","Karim Daud","Sana Tahir","Bashir Saif","Rahima Ghafur","Adel Mukhtar","Farah Idris","Imran Mohebi","Salma Akbar","Reza Hashmi","Nilab Stanikzai"][i],
      classId: ["c-1","c-2","c-3"][i % 3],
      gender: i % 2 ? "F" : "M",
      dob: `200${8 - (i%4)}-0${(i%9)+1}-1${i%9}`,
      parentName: "Hamid Ahmad",
      parentPhone: "+9370000" + String(1000 + i),
      address: "Kabul, Afghanistan",
      admissionDate: "2023-09-01",
      feeStatus: (["paid","due","partial","paid"] as const)[i%4],
    });
  }
  const fees: FeeRecord[] = students.flatMap(s => [
    { id: uid("f"), studentId: s.id, type: "Monthly", amount: 5000, dueDate: "2026-06-05", status: s.feeStatus, paidDate: s.feeStatus === "paid" ? "2026-05-30" : undefined },
  ]);
  const attendance: AttendanceRecord[] = [];
  for (let d = 0; d < 14; d++) {
    const date = new Date(today); date.setDate(date.getDate() - d);
    const ds = date.toISOString().slice(0,10);
    students.forEach((s, idx) => {
      const r = (idx + d) % 10;
      attendance.push({ id: uid("a"), studentId: s.id, date: ds, status: r === 0 ? "absent" : r === 1 ? "leave" : "present", method: "manual" });
    });
  }
  const exams: ExamRecord[] = [
    { id: "e-1", name: "Monthly Test - May", type: "Monthly", classId: "c-1", date: "2026-05-15" },
    { id: "e-2", name: "Midterm Exam", type: "Midterm", classId: "c-1", date: "2026-06-20" },
    { id: "e-3", name: "Final Exam 2025", type: "Final", classId: "c-2", date: "2026-07-10" },
  ];
  const marks: MarkRecord[] = students.slice(0,12).map((s,i) => ({
    id: uid("m"), studentId: s.id, examId: "e-1", subjectId: "sub-1",
    marks: 60 + (i*3) % 35, total: 100, grade: ["A+","A","B+","B","C"][i%5], updatedAt: new Date().toISOString(),
  }));
  const homework: Homework[] = [
    { id: "hw-1", classId: "c-1", subjectId: "sub-1", title: "Algebra Worksheet", description: "Solve Ex 4.1 problems 1-15", dueDate: "2026-06-10", teacherId: "t-1" },
    { id: "hw-2", classId: "c-2", subjectId: "sub-1", title: "Reading Assignment", description: "Read Chapter 5 and summarize", dueDate: "2026-06-12", teacherId: "t-2" },
  ];
  const days = ["Mon","Tue","Wed","Thu","Fri","Sat"];
  const timetable: TimetableEntry[] = [];
  classes.forEach(c => days.forEach(d => {
    for (let p = 1; p <= 5; p++) {
      timetable.push({ id: uid("tt"), classId: c.id, day: d, period: p, subjectId: "sub-1", teacherId: teachers[(p-1)%teachers.length].id });
    }
  }));
  const books: LibraryBook[] = [
    { id: "b-1", title: "Mathematics Grade 9", author: "MoE", isbn: "978-1-001", copies: 30, available: 22 },
    { id: "b-2", title: "English Reader", author: "Oxford", isbn: "978-1-002", copies: 25, available: 18 },
    { id: "b-3", title: "Physics Fundamentals", author: "H. Rahimi", isbn: "978-1-003", copies: 15, available: 10 },
  ];
  const bookIssues: BookIssue[] = [
    { id: "bi-1", bookId: "b-1", studentId: "s-1", issueDate: "2026-05-20", dueDate: "2026-06-05", fine: 0 },
  ];
  const salaries: SalaryRecord[] = teachers.map(t => ({ id: uid("sal"), teacherId: t.id, month: "2026-05", amount: t.salary, status: "paid", paidDate: "2026-05-30" }));
  const transactions: Transaction[] = [
    { id: "tx-1", date: "2026-05-30", type: "income", category: "Fees", description: "May fee collection", amount: 120000 },
    { id: "tx-2", date: "2026-05-30", type: "expense", category: "Salaries", description: "May salaries", amount: 139000 },
    { id: "tx-3", date: "2026-05-15", type: "expense", category: "Utilities", description: "Electricity", amount: 8500 },
    { id: "tx-4", date: "2026-05-12", type: "income", category: "Donation", description: "Community donation", amount: 25000 },
  ];
  const auditLogs: AuditLog[] = [
    { id: "al-1", timestamp: new Date().toISOString(), user: "admin@school.edu", action: "LOGIN", detail: "Successful login", ip: "192.168.1.10" },
    { id: "al-2", timestamp: new Date().toISOString(), user: "yusuf@school.edu", action: "MARKS_UPDATE", detail: "Updated marks for Bilal Ahmad", ip: "192.168.1.22" },
  ];
  const notifications: NotificationItem[] = [
    { id: "n-1", title: "Fee Due Reminder", message: "Monthly fee for June is due in 5 days", type: "warning", date: new Date().toISOString(), read: false, channel: "in-app" },
    { id: "n-2", title: "Exam Schedule Published", message: "Midterm exams start June 20", type: "info", date: new Date().toISOString(), read: false, channel: "in-app" },
  ];
  return { students, teachers, classes, subjects, fees, attendance, exams, marks, homework, timetable, books, bookIssues, salaries, transactions, auditLogs, notifications };
}

function load(): DB {
  if (typeof window === "undefined") return seed();
  const raw = localStorage.getItem(KEY);
  if (raw) { try { return JSON.parse(raw) as DB; } catch { /* */ } }
  const d = seed();
  localStorage.setItem(KEY, JSON.stringify(d));
  return d;
}

function save(db: DB) {
  localStorage.setItem(KEY, JSON.stringify(db));
}

const listeners = new Set<() => void>();
let cache: DB | null = null;

export function getDB(): DB {
  if (!cache) cache = load();
  return cache;
}

export function setDB(updater: (db: DB) => DB) {
  cache = updater(getDB());
  save(cache);
  listeners.forEach(l => l());
}

export function resetDB() {
  localStorage.removeItem(KEY);
  cache = seed();
  save(cache);
  listeners.forEach(l => l());
}

export function useDB(): [DB, (u: (db: DB) => DB) => void] {
  const [, setTick] = useState(0);
  useEffect(() => {
    const l = () => setTick((t: number) => t + 1);
    listeners.add(l);
    return () => { listeners.delete(l); };
  }, []);
  const set = useCallback((u: (db: DB) => DB) => setDB(u), []);
  return [getDB(), set];
}

export { uid };