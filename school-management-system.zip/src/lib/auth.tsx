import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Role = "admin" | "teacher" | "student" | "parent";

export interface AuthUser {
  id: string;
  name: string;
  role: Role;
  email: string;
  avatar?: string;
  linkedId?: string; // student id for parent/student, teacher id for teacher
}

interface AuthCtx {
  user: AuthUser | null;
  login: (role: Role) => void;
  logout: () => void;
}

const Ctx = createContext<AuthCtx | null>(null);
const KEY = "sms_auth_user";

const demoUsers: Record<Role, AuthUser> = {
  admin: { id: "u-admin", name: "Dr. Ahmad Khan", role: "admin", email: "admin@school.edu" },
  teacher: { id: "u-teacher", name: "Mr. Yusuf Karimi", role: "teacher", email: "yusuf@school.edu", linkedId: "t-1" },
  student: { id: "u-student", name: "Bilal Ahmad", role: "student", email: "bilal@school.edu", linkedId: "s-1" },
  parent: { id: "u-parent", name: "Hamid Ahmad", role: "parent", email: "hamid@school.edu", linkedId: "s-1" },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);

  useEffect(() => {
    const raw = typeof window !== "undefined" ? localStorage.getItem(KEY) : null;
    if (raw) {
      try { setUser(JSON.parse(raw)); } catch { /* noop */ }
    }
  }, []);

  const login = (role: Role) => {
    const u = demoUsers[role];
    localStorage.setItem(KEY, JSON.stringify(u));
    setUser(u);
  };
  const logout = () => {
    localStorage.removeItem(KEY);
    setUser(null);
  };

  return <Ctx.Provider value={{ user, login, logout }}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth must be used inside AuthProvider");
  return c;
}