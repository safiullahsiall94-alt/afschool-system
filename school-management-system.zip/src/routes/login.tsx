import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useAuth, type Role } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GraduationCap, Shield, Users, BookOpen, Heart } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Login — Noor Academy" }] }),
  component: LoginPage,
});

const roleCards: { role: Role; label: string; icon: typeof Shield; desc: string; color: string }[] = [
  { role: "admin",   label: "Administrator", icon: Shield,    desc: "Full system access", color: "bg-primary" },
  { role: "teacher", label: "Teacher",       icon: BookOpen,  desc: "Classes, attendance, marks", color: "bg-accent" },
  { role: "student", label: "Student",       icon: Users,     desc: "Profile, results, fees", color: "bg-success" },
  { role: "parent",  label: "Parent",        icon: Heart,     desc: "Track your child's progress", color: "bg-warning" },
];

function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [selected, setSelected] = useState<Role>("admin");
  const [email, setEmail] = useState("admin@school.edu");
  const [password, setPassword] = useState("demo1234");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login(selected);
    toast.success(`Welcome back!`);
    navigate({ to: `/${selected}` as "/admin" });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4" style={{ background: "var(--gradient-primary)" }}>
      <Card className="w-full max-w-5xl grid md:grid-cols-2 overflow-hidden shadow-2xl">
        <div className="p-10 bg-card">
          <div className="flex items-center gap-2 mb-8">
            <div className="size-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center">
              <GraduationCap className="size-6" />
            </div>
            <div>
              <div className="font-bold">Noor Academy</div>
              <div className="text-xs text-muted-foreground">School Management System</div>
            </div>
          </div>
          <h1 className="text-2xl font-bold mb-2">Sign in to your account</h1>
          <p className="text-sm text-muted-foreground mb-6">Select your role and enter credentials</p>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label>Email</Label>
              <Input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
            </div>
            <div>
              <Label>Password</Label>
              <Input value={password} onChange={(e) => setPassword(e.target.value)} type="password" required />
            </div>
            <Button type="submit" className="w-full" size="lg">Sign in as {selected}</Button>
            <p className="text-xs text-muted-foreground text-center">Demo build — any credentials work. Pick a role on the right.</p>
          </form>
        </div>
        <div className="p-10 bg-secondary/50 space-y-3">
          <h2 className="font-semibold mb-4">Choose your role</h2>
          {roleCards.map(r => {
            const Icon = r.icon;
            const active = selected === r.role;
            return (
              <button key={r.role} type="button" onClick={() => setSelected(r.role)}
                className={`w-full text-left p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${active ? "border-primary bg-card shadow-md" : "border-transparent bg-card/50 hover:bg-card"}`}>
                <div className={`size-10 rounded-lg ${r.color} text-primary-foreground flex items-center justify-center`}>
                  <Icon className="size-5" />
                </div>
                <div className="flex-1">
                  <div className="font-medium">{r.label}</div>
                  <div className="text-xs text-muted-foreground">{r.desc}</div>
                </div>
              </button>
            );
          })}
        </div>
      </Card>
    </div>
  );
}