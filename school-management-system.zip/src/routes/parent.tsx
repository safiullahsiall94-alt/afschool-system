import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";
import { AppLayout } from "@/components/AppLayout";
import { useDB } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { StatCard } from "@/components/StatCard";
import { exportCSV } from "@/lib/csv";
import { ClipboardCheck, Award, DollarSign, Bell, Download } from "lucide-react";

export const Route = createFileRoute("/parent")({
  head: () => ({ meta: [{ title: "Parent — Noor Academy" }] }),
  component: ParentPage,
});

function ParentPage() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  if (user.role !== "parent") return <Navigate to={`/${user.role}` as "/admin"} />;
  return (
    <AppLayout role="parent" nav={[{ label: "Dashboard", to: "/parent" }]} title="Parent Portal">
      <ParentContent childId={user.linkedId ?? "s-1"} />
    </AppLayout>
  );
}

function ParentContent({ childId }: { childId: string }) {
  const [db] = useDB();
  const child = db.students.find(s => s.id === childId);
  if (!child) return <Card className="p-6">Child not found</Card>;
  const att = db.attendance.filter(a => a.studentId === childId);
  const pres = att.filter(a => a.status === "present").length;
  const attPct = att.length ? Math.round(pres / att.length * 100) : 0;
  const marks = db.marks.filter(m => m.studentId === childId);
  const avg = marks.length ? Math.round(marks.reduce((s, m) => s + m.marks, 0) / marks.length) : 0;
  const fees = db.fees.filter(f => f.studentId === childId);
  const due = fees.filter(f => f.status !== "paid").reduce((s, f) => s + f.amount, 0);

  return (
    <Tabs defaultValue="dash" className="space-y-4">
      <TabsList>
        <TabsTrigger value="dash">Overview</TabsTrigger>
        <TabsTrigger value="att">Attendance</TabsTrigger>
        <TabsTrigger value="marks">Marks</TabsTrigger>
        <TabsTrigger value="fees">Fees</TabsTrigger>
        <TabsTrigger value="notif">Notifications</TabsTrigger>
      </TabsList>

      <TabsContent value="dash" className="space-y-4">
        <Card className="p-5 bg-gradient-to-br from-primary/5 to-accent/5">
          <div className="flex items-center gap-4">
            <div className="size-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold">{child.name.charAt(0)}</div>
            <div>
              <div className="text-xl font-bold">{child.name}</div>
              <div className="text-sm text-muted-foreground">Roll {child.rollNo} • {db.classes.find(c => c.id === child.classId)?.name}</div>
            </div>
          </div>
        </Card>
        <div className="grid md:grid-cols-3 gap-4">
          <StatCard label="Attendance" value={`${attPct}%`} icon={ClipboardCheck} color={attPct > 75 ? "success" : "warning"} />
          <StatCard label="Average Marks" value={`${avg}/100`} icon={Award} color="primary" />
          <StatCard label="Fees Due" value={`AFN ${due.toLocaleString()}`} icon={DollarSign} color={due ? "destructive" : "success"} />
        </div>
      </TabsContent>

      <TabsContent value="att">
        <Card className="p-4">
          <div className="mb-3"><div className="flex justify-between text-sm mb-1"><span>{child.name}'s attendance</span><span className="font-semibold">{attPct}%</span></div><Progress value={attPct} /></div>
          <Table><TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Status</TableHead></TableRow></TableHeader><TableBody>
            {att.slice(0,14).map(a => <TableRow key={a.id}><TableCell>{a.date}</TableCell><TableCell><Badge variant={a.status === "present" ? "default" : a.status === "absent" ? "destructive" : "secondary"}>{a.status}</Badge></TableCell></TableRow>)}
          </TableBody></Table>
          <Button size="sm" className="mt-3" variant="outline" onClick={() => exportCSV(`${child.name}-attendance.csv`, att)}><Download className="size-4 mr-1" />Download Report</Button>
        </Card>
      </TabsContent>

      <TabsContent value="marks">
        <Card className="p-4">
          <Table><TableHeader><TableRow><TableHead>Exam</TableHead><TableHead>Subject</TableHead><TableHead>Marks</TableHead><TableHead>Grade</TableHead></TableRow></TableHeader><TableBody>
            {marks.map(m => <TableRow key={m.id}><TableCell>{db.exams.find(e => e.id === m.examId)?.name}</TableCell><TableCell>{db.subjects.find(s => s.id === m.subjectId)?.name}</TableCell><TableCell>{m.marks}/{m.total}</TableCell><TableCell><Badge>{m.grade}</Badge></TableCell></TableRow>)}
          </TableBody></Table>
        </Card>
      </TabsContent>

      <TabsContent value="fees">
        <Card className="p-4">
          <Table><TableHeader><TableRow><TableHead>Type</TableHead><TableHead>Amount</TableHead><TableHead>Due</TableHead><TableHead>Status</TableHead></TableRow></TableHeader><TableBody>
            {fees.map(f => <TableRow key={f.id}><TableCell>{f.type}</TableCell><TableCell>AFN {f.amount.toLocaleString()}</TableCell><TableCell>{f.dueDate}</TableCell><TableCell><Badge variant={f.status === "paid" ? "default" : "destructive"}>{f.status}</Badge></TableCell></TableRow>)}
          </TableBody></Table>
        </Card>
      </TabsContent>

      <TabsContent value="notif">
        <Card className="p-4 space-y-2">
          {db.notifications.map(n => (
            <div key={n.id} className="p-3 border rounded-lg flex items-start gap-3">
              <Bell className="size-4 text-primary mt-1" />
              <div className="flex-1"><div className="font-medium text-sm">{n.title}</div><div className="text-xs text-muted-foreground">{n.message}</div></div>
              <Badge variant="outline">{n.channel}</Badge>
            </div>
          ))}
        </Card>
      </TabsContent>
    </Tabs>
  );
}