import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Noor Academy — School Management System" },
      { name: "description", content: "Complete school management: admin, teachers, students, parents, attendance, fees, exams." },
      { property: "og:title", content: "Noor Academy — School Management System" },
      { property: "og:description", content: "Complete school management dashboard." },
    ],
  }),
  component: Index,
});

function Index() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  return <Navigate to={`/${user.role}` as "/admin"} />;
}
