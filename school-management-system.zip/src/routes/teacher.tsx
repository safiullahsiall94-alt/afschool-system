import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";
import { AppLayout } from "@/components/AppLayout";
import { useDB, uid, type AttendanceRecord, type MarkRecord, type Homework } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { StatCard } from "@/components/StatCard";
import { Users, BookOpen, ClipboardCheck, FileText, Calendar, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";

export const Route = createFileRoute("/teacher")({
  head: () => ({ meta: [{ title: "Teacher — Noor Academy" }] }),
  component: TeacherPage,
});

function TeacherPage() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  if (user.role !== "teacher") return <Navigate to={`/${user.role}` as "/admin"} />;
  return (
    <AppLayout role="teacher" nav={[{ label: "Dashboard", to: "/teacher" }]} title="Teacher Panel">
      <TeacherTabs teacherId={user.linkedId ?? "t-1"} />
    </AppLayout>
  );
}

function TeacherTabs({ teacherId }: { teacherId: string }) {
  const [db, setDB] = useDB();
  const myClasses = db.classes.filter(c => c.teacherId === teacherId);
  const myClassIds = new Set(myClasses.map(c => c.id));
  const myStudents = db.students.filter(s => myClassIds.has(s.classId));
  const myHomework = db.homework.filter(h => h.teacherId === teacherId);
  const todayStr = new Date().toISOString().slice(0,10);
  const todayAttendance = db.attendance.filter(a => a.date === todayStr && myStudents.some(s => s.id === a.studentId));
  const presentToday = todayAttendance.filter(a => a.status === "present").length;

  return (
    <Tabs defaultValue="dash" className="space-y-4">
      <TabsList>
        <TabsTrigger value="dash">Dashboard</TabsTrigger>
        <TabsTrigger value="classes">My Classes</TabsTrigger>
        <TabsTrigger value="attendance">Attendance</TabsTrigger>
        <TabsTrigger value="marks">Marks</TabsTrigger>
        <TabsTrigger value="homework">Homework</TabsTrigger>
        <TabsTrigger value="timetable">Timetable</TabsTrigger>
      </TabsList>

      <TabsContent value="dash" className="space-y-4">
        <div className="grid md:grid-cols-4 gap-4">
          <StatCard label="My Classes" value={myClasses.length} icon={BookOpen} color="primary" />
          <StatCard label="My Students" value={myStudents.length} icon={Users} color="accent" />
          <StatCard label="Present Today" value={presentToday} icon={ClipboardCheck} color="success" hint={`of ${myStudents.length}`} />
          <StatCard label="Homework Assigned" value={myHomework.length} icon={FileText} color="warning" />
        </div>
        <Card className="p-5">
          <h3 className="font-semibold mb-3">Recent Activity</h3>
          <ul className="text-sm space-y-2 text-muted-foreground">
            <li>• Marked attendance for {myClasses[0]?.name ?? "class"} ({presentToday}/{myStudents.length} present)</li>
            <li>• {myHomework.length} active homework assignments</li>
            <li>• Restrictions: cannot delete students, change settings, or access financials</li>
          </ul>
        </Card>
      </TabsContent>

      <TabsContent value="classes">
        <Card className="p-4">
          <h3 className="font-semibold mb-3">Assigned Classes</h3>
          <Table>
            <TableHeader><TableRow><TableHead>Class</TableHead><TableHead>Students</TableHead><TableHead>Capacity</TableHead></TableRow></TableHeader>
            <TableBody>
              {myClasses.map(c => (
                <TableRow key={c.id}>
                  <TableCell>{c.name} - {c.section}</TableCell>
                  <TableCell>{db.students.filter(s => s.classId === c.id).length}</TableCell>
                  <TableCell>{c.capacity}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </TabsContent>

      <TabsContent value="attendance"><AttendanceTaker teacherId={teacherId} /></TabsContent>
      <TabsContent value="marks"><MarksEntry teacherId={teacherId} /></TabsContent>
      <TabsContent value="homework"><HomeworkManager teacherId={teacherId} /></TabsContent>
      <TabsContent value="timetable"><TeacherTimetable teacherId={teacherId} /></TabsContent>
    </Tabs>
  );
}

function AttendanceTaker({ teacherId }: { teacherId: string }) {
  const [db, setDB] = useDB();
  const myClasses = db.classes.filter(c => c.teacherId === teacherId);
  const [classId, setClassId] = useState(myClasses[0]?.id ?? "");
  const [date, setDate] = useState(new Date().toISOString().slice(0,10));
  const students = db.students.filter(s => s.classId === classId);
  const existing = db.attendance.filter(a => a.date === date && students.some(s => s.id === a.studentId));
  const getStatus = (sid: string) => existing.find(a => a.studentId === sid)?.status;

  const mark = (sid: string, status: AttendanceRecord["status"], method: AttendanceRecord["method"] = "manual") => {
    setDB(db => ({
      ...db,
      attendance: [
        ...db.attendance.filter(a => !(a.studentId === sid && a.date === date)),
        { id: uid("a"), studentId: sid, date, status, method },
      ],
    }));
  };

  const markAllPresent = () => {
    students.forEach(s => mark(s.id, "present"));
    toast.success(`Marked all ${students.length} present`);
  };

  const simulateFace = () => {
    students.forEach((s, i) => mark(s.id, i % 7 === 0 ? "absent" : "present", "face"));
    toast.success("Face recognition complete — attendance marked");
  };

  const simulateQR = () => {
    const random = students[Math.floor(Math.random() * students.length)];
    if (random) { mark(random.id, "present", "qr"); toast.success(`QR check-in: ${random.name}`); }
  };

  return (
    <Card className="p-4 space-y-4">
      <div className="flex flex-wrap gap-3 items-end">
        <div><Label>Class</Label>
          <Select value={classId} onValueChange={setClassId}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>{myClasses.map(c => <SelectItem key={c.id} value={c.id}>{c.name} {c.section}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Date</Label><Input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-44" /></div>
        <Button onClick={markAllPresent}>Mark All Present</Button>
        <Button variant="outline" onClick={simulateFace}>📸 Face Recognition</Button>
        <Button variant="outline" onClick={simulateQR}>📱 QR Scan</Button>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>Roll</TableHead><TableHead>Name</TableHead><TableHead>Status</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader>
        <TableBody>
          {students.map(s => {
            const st = getStatus(s.id);
            return (
              <TableRow key={s.id}>
                <TableCell>{s.rollNo}</TableCell>
                <TableCell>{s.name}</TableCell>
                <TableCell>{st ? <Badge variant={st === "present" ? "default" : st === "absent" ? "destructive" : "secondary"}>{st}</Badge> : <span className="text-muted-foreground text-xs">Not marked</span>}</TableCell>
                <TableCell className="space-x-1">
                  <Button size="sm" variant={st === "present" ? "default" : "outline"} onClick={() => mark(s.id, "present")}>P</Button>
                  <Button size="sm" variant={st === "absent" ? "destructive" : "outline"} onClick={() => mark(s.id, "absent")}>A</Button>
                  <Button size="sm" variant={st === "leave" ? "secondary" : "outline"} onClick={() => mark(s.id, "leave")}>L</Button>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </Card>
  );
}

function HomeworkManager({ teacherId }: { teacherId: string }) {
  const [db, setDB] = useDB();
  const myHw = db.homework.filter(h => h.teacherId === teacherId);
  const [classId, setClassId] = useState(db.classes[0]?.id ?? "");
  const [subjectId, setSubjectId] = useState(db.subjects[0]?.id ?? "");
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [due, setDue] = useState(new Date(Date.now() + 7*864e5).toISOString().slice(0,10));

  const add = () => {
    if (!title) return;
    setDB(db => ({ ...db, homework: [{ id: uid("hw"), classId, subjectId, title, description: desc, dueDate: due, teacherId }, ...db.homework] }));
    setTitle(""); setDesc("");
    toast.success("Homework assigned");
  };
  const remove = (id: string) => setDB(db => ({ ...db, homework: db.homework.filter(h => h.id !== id) }));

  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <Card className="p-4 space-y-3">
        <h3 className="font-semibold">Assign New Homework</h3>
        <div><Label>Title</Label><Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Algebra problems" /></div>
        <div><Label>Description</Label><Textarea value={desc} onChange={e => setDesc(e.target.value)} /></div>
        <div className="grid grid-cols-3 gap-2">
          <div><Label>Class</Label><Select value={classId} onValueChange={setClassId}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{db.classes.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Subject</Label><Select value={subjectId} onValueChange={setSubjectId}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{db.subjects.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Due</Label><Input type="date" value={due} onChange={e => setDue(e.target.value)} /></div>
        </div>
        <Button onClick={add}>Assign</Button>
      </Card>
      <Card className="p-4">
        <h3 className="font-semibold mb-3">My Homework ({myHw.length})</h3>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {myHw.map(h => (
            <div key={h.id} className="p-3 border rounded-lg">
              <div className="flex justify-between"><div className="font-medium">{h.title}</div><Button size="sm" variant="ghost" onClick={() => remove(h.id)}>×</Button></div>
              <div className="text-xs text-muted-foreground">{h.description}</div>
              <div className="text-xs mt-1">Due: {h.dueDate}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function TeacherTimetable({ teacherId }: { teacherId: string }) {
  const [db] = useDB();
  const my = db.timetable.filter(t => t.teacherId === teacherId);
  const days = ["Mon","Tue","Wed","Thu","Fri","Sat"];
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-3">My Weekly Timetable</h3>
      <Table>
        <TableHeader><TableRow><TableHead>Day</TableHead>{[1,2,3,4,5].map(p => <TableHead key={p}>Period {p}</TableHead>)}</TableRow></TableHeader>
        <TableBody>
          {days.map(d => (
            <TableRow key={d}>
              <TableCell className="font-medium">{d}</TableCell>
              {[1,2,3,4,5].map(p => {
                const e = my.find(x => x.day === d && x.period === p);
                const cls = e ? db.classes.find(c => c.id === e.classId) : null;
                return <TableCell key={p} className="text-xs">{cls ? `${cls.name}` : "—"}</TableCell>;
              })}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
}

function MarksEntry({ teacherId }: { teacherId: string }) {
  const [db, setDB] = useDB();
  const myClasses = db.classes.filter(c => c.teacherId === teacherId);
  const [classId, setClassId] = useState(myClasses[0]?.id ?? "");
  const [examId, setExamId] = useState(db.exams[0]?.id ?? "");
  const [subjectId, setSubjectId] = useState(db.subjects[0]?.id ?? "");
  const students = db.students.filter(s => s.classId === classId);
  const getMark = (sid: string) => db.marks.find(m => m.studentId === sid && m.examId === examId && m.subjectId === subjectId);

  const setMark = (sid: string, val: number) => {
    const grade = val >= 90 ? "A+" : val >= 80 ? "A" : val >= 70 ? "B+" : val >= 60 ? "B" : val >= 50 ? "C" : "F";
    setDB(db => ({
      ...db,
      marks: [
        ...db.marks.filter(m => !(m.studentId === sid && m.examId === examId && m.subjectId === subjectId)),
        { id: uid("m"), studentId: sid, examId, subjectId, marks: val, total: 100, grade, updatedAt: new Date().toISOString() },
      ],
      auditLogs: [{ id: uid("al"), timestamp: new Date().toISOString(), user: "teacher", action: "MARKS_UPDATE", detail: `Set marks ${val} for student ${sid}`, ip: "192.168.1.22" }, ...db.auditLogs],
    }));
  };

  return (
    <Card className="p-4 space-y-4">
      <div className="flex flex-wrap gap-3 items-end">
        <div><Label>Class</Label><Select value={classId} onValueChange={setClassId}><SelectTrigger className="w-40"><SelectValue /></SelectTrigger><SelectContent>{myClasses.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Exam</Label><Select value={examId} onValueChange={setExamId}><SelectTrigger className="w-48"><SelectValue /></SelectTrigger><SelectContent>{db.exams.map(e => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Subject</Label><Select value={subjectId} onValueChange={setSubjectId}><SelectTrigger className="w-40"><SelectValue /></SelectTrigger><SelectContent>{db.subjects.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select></div>
      </div>
      <div className="text-xs text-muted-foreground">⚠️ Every mark change is logged in audit log and admins are notified.</div>
      <Table>
        <TableHeader><TableRow><TableHead>Student</TableHead><TableHead>Marks /100</TableHead><TableHead>Grade</TableHead></TableRow></TableHeader>
        <TableBody>
          {students.map(s => {
            const m = getMark(s.id);
            return (
              <TableRow key={s.id}>
                <TableCell>{s.name}</TableCell>
                <TableCell><Input type="number" min={0} max={100} defaultValue={m?.marks ?? ""} className="w-24" onBlur={e => { const v = parseInt(e.target.value); if (!isNaN(v)) setMark(s.id, v); }} /></TableCell>
                <TableCell>{m && <Badge>{m.grade}</Badge>}</TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </Card>
  );
}