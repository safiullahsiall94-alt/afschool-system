import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";
import { AppLayout } from "@/components/AppLayout";
import { useDB } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { StatCard } from "@/components/StatCard";
import { downloadText } from "@/lib/csv";
import { ClipboardCheck, Award, DollarSign, BookOpen, Download } from "lucide-react";

export const Route = createFileRoute("/student")({
  head: () => ({ meta: [{ title: "Student — Noor Academy" }] }),
  component: StudentPage,
});

function StudentPage() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  if (user.role !== "student") return <Navigate to={`/${user.role}` as "/admin"} />;
  return (
    <AppLayout role="student" nav={[{ label: "Dashboard", to: "/student" }]} title="Student Portal">
      <StudentContent studentId={user.linkedId ?? "s-1"} />
    </AppLayout>
  );
}

function StudentContent({ studentId }: { studentId: string }) {
  const [db] = useDB();
  const me = db.students.find(s => s.id === studentId);
  if (!me) return <Card className="p-6">Student not found</Card>;
  const myClass = db.classes.find(c => c.id === me.classId);
  const myAttendance = db.attendance.filter(a => a.studentId === studentId);
  const presentCount = myAttendance.filter(a => a.status === "present").length;
  const attendancePct = myAttendance.length ? Math.round((presentCount / myAttendance.length) * 100) : 0;
  const myMarks = db.marks.filter(m => m.studentId === studentId);
  const avgMarks = myMarks.length ? Math.round(myMarks.reduce((s, m) => s + m.marks, 0) / myMarks.length) : 0;
  const myFees = db.fees.filter(f => f.studentId === studentId);
  const dueFees = myFees.filter(f => f.status !== "paid").reduce((s, f) => s + f.amount, 0);
  const myHw = db.homework.filter(h => h.classId === me.classId);

  const downloadResult = () => {
    const lines = [
      "═══════════════════════════════════════",
      "       NOOR ACADEMY — REPORT CARD       ",
      "═══════════════════════════════════════",
      `Student: ${me.name}    Roll: ${me.rollNo}`,
      `Class: ${myClass?.name} ${myClass?.section}`,
      `Attendance: ${attendancePct}%`,
      "---------------------------------------",
      "Subject                Marks    Grade",
      ...myMarks.map(m => {
        const sub = db.subjects.find(s => s.id === m.subjectId)?.name ?? "—";
        return `${sub.padEnd(20)} ${String(m.marks).padStart(4)}/${m.total}   ${m.grade}`;
      }),
      "---------------------------------------",
      `Average: ${avgMarks}/100`,
      "═══════════════════════════════════════",
    ].join("\n");
    downloadText(`report-${me.rollNo}.txt`, lines);
  };

  return (
    <Tabs defaultValue="dash" className="space-y-4">
      <TabsList>
        <TabsTrigger value="dash">Dashboard</TabsTrigger>
        <TabsTrigger value="profile">Profile</TabsTrigger>
        <TabsTrigger value="attendance">Attendance</TabsTrigger>
        <TabsTrigger value="marks">Marks</TabsTrigger>
        <TabsTrigger value="timetable">Timetable</TabsTrigger>
        <TabsTrigger value="homework">Homework</TabsTrigger>
        <TabsTrigger value="fees">Fees</TabsTrigger>
        <TabsTrigger value="certs">Certificates</TabsTrigger>
      </TabsList>

      <TabsContent value="dash" className="space-y-4">
        <div className="grid md:grid-cols-4 gap-4">
          <StatCard label="Attendance" value={`${attendancePct}%`} icon={ClipboardCheck} color={attendancePct > 75 ? "success" : "warning"} />
          <StatCard label="Average Marks" value={`${avgMarks}/100`} icon={Award} color="primary" />
          <StatCard label="Fees Due" value={`AFN ${dueFees.toLocaleString()}`} icon={DollarSign} color={dueFees ? "destructive" : "success"} />
          <StatCard label="Homework" value={myHw.length} icon={BookOpen} color="accent" />
        </div>
        <Card className="p-5">
          <h3 className="font-semibold mb-2">Welcome, {me.name}!</h3>
          <p className="text-sm text-muted-foreground">You are enrolled in {myClass?.name} - Section {myClass?.section}. Keep up the great work.</p>
        </Card>
      </TabsContent>

      <TabsContent value="profile">
        <Card className="p-6 space-y-3">
          <h3 className="font-semibold text-lg">My Profile</h3>
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div><span className="text-muted-foreground">Name:</span> <b>{me.name}</b></div>
            <div><span className="text-muted-foreground">Roll No:</span> <b>{me.rollNo}</b></div>
            <div><span className="text-muted-foreground">Class:</span> <b>{myClass?.name} {myClass?.section}</b></div>
            <div><span className="text-muted-foreground">Gender:</span> <b>{me.gender === "M" ? "Male" : "Female"}</b></div>
            <div><span className="text-muted-foreground">DOB:</span> <b>{me.dob}</b></div>
            <div><span className="text-muted-foreground">Admission:</span> <b>{me.admissionDate}</b></div>
            <div><span className="text-muted-foreground">Parent:</span> <b>{me.parentName}</b></div>
            <div><span className="text-muted-foreground">Phone:</span> <b>{me.parentPhone}</b></div>
            <div className="md:col-span-2"><span className="text-muted-foreground">Address:</span> <b>{me.address}</b></div>
          </div>
        </Card>
      </TabsContent>

      <TabsContent value="attendance">
        <Card className="p-4">
          <div className="mb-3">
            <div className="flex justify-between text-sm mb-1"><span>Attendance Rate</span><span className="font-semibold">{attendancePct}%</span></div>
            <Progress value={attendancePct} />
          </div>
          <Table>
            <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Status</TableHead><TableHead>Method</TableHead></TableRow></TableHeader>
            <TableBody>
              {myAttendance.slice(0, 14).map(a => (
                <TableRow key={a.id}>
                  <TableCell>{a.date}</TableCell>
                  <TableCell><Badge variant={a.status === "present" ? "default" : a.status === "absent" ? "destructive" : "secondary"}>{a.status}</Badge></TableCell>
                  <TableCell className="text-xs text-muted-foreground">{a.method}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </TabsContent>

      <TabsContent value="marks">
        <Card className="p-4">
          <div className="flex justify-between mb-3">
            <h3 className="font-semibold">My Marks</h3>
            <Button size="sm" onClick={downloadResult}><Download className="size-4 mr-1" />Download Result</Button>
          </div>
          <Table>
            <TableHeader><TableRow><TableHead>Exam</TableHead><TableHead>Subject</TableHead><TableHead>Marks</TableHead><TableHead>Grade</TableHead></TableRow></TableHeader>
            <TableBody>
              {myMarks.map(m => (
                <TableRow key={m.id}>
                  <TableCell>{db.exams.find(e => e.id === m.examId)?.name ?? "—"}</TableCell>
                  <TableCell>{db.subjects.find(s => s.id === m.subjectId)?.name ?? "—"}</TableCell>
                  <TableCell>{m.marks}/{m.total}</TableCell>
                  <TableCell><Badge>{m.grade}</Badge></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </TabsContent>

      <TabsContent value="timetable">
        <Card className="p-4">
          <h3 className="font-semibold mb-3">Class Timetable</h3>
          <Table>
            <TableHeader><TableRow><TableHead>Day</TableHead>{[1,2,3,4,5].map(p => <TableHead key={p}>P{p}</TableHead>)}</TableRow></TableHeader>
            <TableBody>
              {["Mon","Tue","Wed","Thu","Fri","Sat"].map(d => (
                <TableRow key={d}>
                  <TableCell className="font-medium">{d}</TableCell>
                  {[1,2,3,4,5].map(p => {
                    const e = db.timetable.find(t => t.classId === me.classId && t.day === d && t.period === p);
                    const sub = e ? db.subjects.find(s => s.id === e.subjectId)?.name : "—";
                    return <TableCell key={p} className="text-xs">{sub ?? "—"}</TableCell>;
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </TabsContent>

      <TabsContent value="homework">
        <Card className="p-4 space-y-2">
          <h3 className="font-semibold mb-2">Assigned Homework</h3>
          {myHw.map(h => (
            <div key={h.id} className="p-3 border rounded-lg">
              <div className="flex justify-between"><div className="font-medium">{h.title}</div><Badge variant="outline">Due {h.dueDate}</Badge></div>
              <div className="text-xs text-muted-foreground mt-1">{h.description}</div>
            </div>
          ))}
        </Card>
      </TabsContent>

      <TabsContent value="fees">
        <Card className="p-4">
          <Table>
            <TableHeader><TableRow><TableHead>Type</TableHead><TableHead>Amount</TableHead><TableHead>Due Date</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
            <TableBody>
              {myFees.map(f => (
                <TableRow key={f.id}>
                  <TableCell>{f.type}</TableCell>
                  <TableCell>AFN {f.amount.toLocaleString()}</TableCell>
                  <TableCell>{f.dueDate}</TableCell>
                  <TableCell><Badge variant={f.status === "paid" ? "default" : "destructive"}>{f.status}</Badge></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </TabsContent>

      <TabsContent value="certs">
        <Card className="p-6 grid md:grid-cols-3 gap-4">
          {["Character Certificate","Completion Certificate","Achievement Award"].map(c => (
            <Card key={c} className="p-5 text-center bg-gradient-to-br from-primary/10 to-accent/10">
              <Award className="size-12 mx-auto text-primary mb-3" />
              <div className="font-semibold mb-2">{c}</div>
              <Button size="sm" onClick={() => downloadText(`${c.replace(/\s+/g,"-")}-${me.rollNo}.txt`, `NOOR ACADEMY\n\nThis is to certify that ${me.name} (Roll ${me.rollNo}) has been awarded the ${c}.\n\nIssued: ${new Date().toLocaleDateString()}\n\nPrincipal Signature`)}><Download className="size-4 mr-1" />Download</Button>
            </Card>
          ))}
        </Card>
      </TabsContent>
    </Tabs>
  );
}