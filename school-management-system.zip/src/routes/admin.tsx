import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";
import { AppLayout } from "@/components/AppLayout";
import { useState } from "react";
import { useDB, uid } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatCard } from "@/components/StatCard";
import { exportCSV, downloadText } from "@/lib/csv";
import { Users, GraduationCap, Briefcase, DollarSign, Plus, Download, Trash2, BookOpen, Calendar, FileText, Library, Wallet, Activity, Shield, Bell, IdCard, Award, ClipboardCheck, Settings, Database } from "lucide-react";
import { toast } from "sonner";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin — Noor Academy" }] }),
  component: AdminPage,
});

const adminNav = [
  { label: "Dashboard", to: "/admin" },
];

function AdminPage() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  if (user.role !== "admin") return <Navigate to={`/${user.role}` as "/admin"} />;
  return (
    <AppLayout role="admin" nav={adminNav} title="Admin Dashboard">
      <AdminTabs />
    </AppLayout>
  );
}

function AdminTabs() {
  return (
    <Tabs defaultValue="dashboard" className="space-y-4">
      <div className="overflow-x-auto -mx-6 px-6">
        <TabsList className="inline-flex w-auto">
          <TabsTrigger value="dashboard"><Activity className="size-4 mr-1" />Dashboard</TabsTrigger>
          <TabsTrigger value="students"><Users className="size-4 mr-1" />Students</TabsTrigger>
          <TabsTrigger value="teachers"><GraduationCap className="size-4 mr-1" />Teachers</TabsTrigger>
          <TabsTrigger value="parents">Parents</TabsTrigger>
          <TabsTrigger value="classes">Classes</TabsTrigger>
          <TabsTrigger value="fees"><DollarSign className="size-4 mr-1" />Fees</TabsTrigger>
          <TabsTrigger value="exams"><FileText className="size-4 mr-1" />Exams</TabsTrigger>
          <TabsTrigger value="attendance"><ClipboardCheck className="size-4 mr-1" />Attendance</TabsTrigger>
          <TabsTrigger value="timetable"><Calendar className="size-4 mr-1" />Timetable</TabsTrigger>
          <TabsTrigger value="homework">Homework</TabsTrigger>
          <TabsTrigger value="library"><Library className="size-4 mr-1" />Library</TabsTrigger>
          <TabsTrigger value="salaries"><Briefcase className="size-4 mr-1" />Salaries</TabsTrigger>
          <TabsTrigger value="accounting"><Wallet className="size-4 mr-1" />Accounting</TabsTrigger>
          <TabsTrigger value="audit"><Shield className="size-4 mr-1" />Audit Logs</TabsTrigger>
          <TabsTrigger value="notifications"><Bell className="size-4 mr-1" />Notifications</TabsTrigger>
          <TabsTrigger value="idcards"><IdCard className="size-4 mr-1" />ID Cards</TabsTrigger>
          <TabsTrigger value="certs"><Award className="size-4 mr-1" />Certificates</TabsTrigger>
          <TabsTrigger value="settings"><Settings className="size-4 mr-1" />Settings</TabsTrigger>
        </TabsList>
      </div>
      <TabsContent value="dashboard"><DashboardTab /></TabsContent>
      <TabsContent value="students"><StudentsTab /></TabsContent>
      <TabsContent value="teachers"><TeachersTab /></TabsContent>
      <TabsContent value="parents"><ParentsTab /></TabsContent>
      <TabsContent value="classes"><ClassesTab /></TabsContent>
      <TabsContent value="fees"><FeesTab /></TabsContent>
      <TabsContent value="exams"><ExamsTab /></TabsContent>
      <TabsContent value="attendance"><AttendanceTab /></TabsContent>
      <TabsContent value="timetable"><TimetableTab /></TabsContent>
      <TabsContent value="homework"><HomeworkTab /></TabsContent>
      <TabsContent value="library"><LibraryTab /></TabsContent>
      <TabsContent value="salaries"><SalariesTab /></TabsContent>
      <TabsContent value="accounting"><AccountingTab /></TabsContent>
      <TabsContent value="audit"><AuditTab /></TabsContent>
      <TabsContent value="notifications"><NotificationsTab /></TabsContent>
      <TabsContent value="idcards"><IdCardsTab /></TabsContent>
      <TabsContent value="certs"><CertificatesTab /></TabsContent>
      <TabsContent value="settings"><SettingsTab /></TabsContent>
    </Tabs>
  );
}

function StudentsTab() {
  const [db, setDB] = useDB();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", rollNo: "", classId: db.classes[0]?.id ?? "", parentName: "", parentPhone: "" });
  const add = () => {
    if (!form.name) return;
    setDB(d => ({ ...d, students: [{ id: uid("s"), ...form, gender: "M", dob: "2010-01-01", address: "—", admissionDate: new Date().toISOString().slice(0,10), feeStatus: "due" }, ...d.students] }));
    toast.success("Student added");
    setOpen(false); setForm({ name: "", rollNo: "", classId: db.classes[0]?.id ?? "", parentName: "", parentPhone: "" });
  };
  const remove = (id: string) => { setDB(d => ({ ...d, students: d.students.filter(s => s.id !== id) })); toast.success("Removed"); };

  return (
    <Card className="p-4">
      <div className="flex justify-between mb-4 flex-wrap gap-2">
        <h3 className="font-semibold">Students ({db.students.length})</h3>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => exportCSV("students.csv", db.students)}><Download className="size-4 mr-1" />Export</Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button size="sm"><Plus className="size-4 mr-1" />Add Student</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New Student</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Name</Label><Input value={form.name} onChange={e => setForm({...form, name: e.target.value})} /></div>
                <div><Label>Roll No</Label><Input value={form.rollNo} onChange={e => setForm({...form, rollNo: e.target.value})} /></div>
                <div><Label>Class</Label><Select value={form.classId} onValueChange={v => setForm({...form, classId: v})}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{db.classes.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select></div>
                <div><Label>Parent Name</Label><Input value={form.parentName} onChange={e => setForm({...form, parentName: e.target.value})} /></div>
                <div><Label>Parent Phone</Label><Input value={form.parentPhone} onChange={e => setForm({...form, parentPhone: e.target.value})} /></div>
              </div>
              <DialogFooter><Button onClick={add}>Save</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>Roll</TableHead><TableHead>Name</TableHead><TableHead>Class</TableHead><TableHead>Parent</TableHead><TableHead>Fee</TableHead><TableHead></TableHead></TableRow></TableHeader>
        <TableBody>
          {db.students.map(s => (
            <TableRow key={s.id}>
              <TableCell>{s.rollNo}</TableCell>
              <TableCell>{s.name}</TableCell>
              <TableCell>{db.classes.find(c => c.id === s.classId)?.name}</TableCell>
              <TableCell>{s.parentName}<div className="text-xs text-muted-foreground">{s.parentPhone}</div></TableCell>
              <TableCell><Badge variant={s.feeStatus === "paid" ? "default" : "destructive"}>{s.feeStatus}</Badge></TableCell>
              <TableCell><Button size="sm" variant="ghost" onClick={() => remove(s.id)}><Trash2 className="size-4" /></Button></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
}
function TeachersTab() {
  const [db, setDB] = useDB();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: "", empId: "", subject: "", phone: "", email: "", salary: 30000 });
  const add = () => {
    if (!f.name) return;
    setDB(d => ({ ...d, teachers: [{ id: uid("t"), ...f, joiningDate: new Date().toISOString().slice(0,10) }, ...d.teachers] }));
    toast.success("Teacher added"); setOpen(false);
    setF({ name: "", empId: "", subject: "", phone: "", email: "", salary: 30000 });
  };
  return (
    <Card className="p-4">
      <div className="flex justify-between mb-4">
        <h3 className="font-semibold">Teachers ({db.teachers.length})</h3>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => exportCSV("teachers.csv", db.teachers)}><Download className="size-4 mr-1" />Export</Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button size="sm"><Plus className="size-4 mr-1" />Add Teacher</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New Teacher</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Name</Label><Input value={f.name} onChange={e => setF({...f, name: e.target.value})} /></div>
                <div><Label>Employee ID</Label><Input value={f.empId} onChange={e => setF({...f, empId: e.target.value})} /></div>
                <div><Label>Subject</Label><Input value={f.subject} onChange={e => setF({...f, subject: e.target.value})} /></div>
                <div><Label>Phone</Label><Input value={f.phone} onChange={e => setF({...f, phone: e.target.value})} /></div>
                <div><Label>Email</Label><Input value={f.email} onChange={e => setF({...f, email: e.target.value})} /></div>
                <div><Label>Salary (AFN)</Label><Input type="number" value={f.salary} onChange={e => setF({...f, salary: parseInt(e.target.value)||0})} /></div>
              </div>
              <DialogFooter><Button onClick={add}>Save</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>ID</TableHead><TableHead>Name</TableHead><TableHead>Subject</TableHead><TableHead>Phone</TableHead><TableHead>Salary</TableHead><TableHead></TableHead></TableRow></TableHeader>
        <TableBody>
          {db.teachers.map(t => (
            <TableRow key={t.id}>
              <TableCell>{t.empId}</TableCell>
              <TableCell>{t.name}</TableCell>
              <TableCell>{t.subject}</TableCell>
              <TableCell>{t.phone}</TableCell>
              <TableCell>AFN {t.salary.toLocaleString()}</TableCell>
              <TableCell><Button size="sm" variant="ghost" onClick={() => { setDB(d => ({...d, teachers: d.teachers.filter(x => x.id !== t.id)})); toast.success("Removed"); }}><Trash2 className="size-4" /></Button></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
}
function ClassesTab() {
  const [db] = useDB();
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-3">Classes & Subjects</h3>
      <div className="grid md:grid-cols-3 gap-4">
        {db.classes.map(c => {
          const teacher = db.teachers.find(t => t.id === c.teacherId);
          const students = db.students.filter(s => s.classId === c.id).length;
          const subjects = db.subjects.filter(s => s.classId === c.id);
          return (
            <Card key={c.id} className="p-4 border-l-4 border-l-primary">
              <div className="font-bold text-lg">{c.name} - {c.section}</div>
              <div className="text-sm text-muted-foreground mb-2">Class Teacher: {teacher?.name}</div>
              <div className="text-sm">Students: <b>{students}/{c.capacity}</b></div>
              <div className="text-xs text-muted-foreground mt-2">Subjects: {subjects.map(s => s.name).join(", ") || "—"}</div>
            </Card>
          );
        })}
      </div>
    </Card>
  );
}

function FeesTab() {
  const [db, setDB] = useDB();
  const markPaid = (id: string) => { setDB(d => ({ ...d, fees: d.fees.map(f => f.id === id ? { ...f, status: "paid", paidDate: new Date().toISOString().slice(0,10) } : f) })); toast.success("Marked paid + receipt generated"); };
  const totalDue = db.fees.filter(f => f.status !== "paid").reduce((s,f) => s+f.amount, 0);
  const totalPaid = db.fees.filter(f => f.status === "paid").reduce((s,f) => s+f.amount, 0);
  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-3 gap-4">
        <StatCard label="Collected" value={`AFN ${totalPaid.toLocaleString()}`} icon={DollarSign} color="success" />
        <StatCard label="Due" value={`AFN ${totalDue.toLocaleString()}`} icon={Wallet} color="destructive" />
        <StatCard label="Records" value={db.fees.length} icon={FileText} color="primary" />
      </div>
      <Card className="p-4">
        <div className="flex justify-between mb-3"><h3 className="font-semibold">Fee Records</h3><Button size="sm" variant="outline" onClick={() => exportCSV("fees.csv", db.fees)}><Download className="size-4 mr-1" />Export</Button></div>
        <Table>
          <TableHeader><TableRow><TableHead>Student</TableHead><TableHead>Type</TableHead><TableHead>Amount</TableHead><TableHead>Due</TableHead><TableHead>Status</TableHead><TableHead></TableHead></TableRow></TableHeader>
          <TableBody>
            {db.fees.slice(0, 30).map(f => {
              const s = db.students.find(x => x.id === f.studentId);
              return (
                <TableRow key={f.id}>
                  <TableCell>{s?.name}</TableCell>
                  <TableCell>{f.type}</TableCell>
                  <TableCell>AFN {f.amount.toLocaleString()}</TableCell>
                  <TableCell>{f.dueDate}</TableCell>
                  <TableCell><Badge variant={f.status === "paid" ? "default" : "destructive"}>{f.status}</Badge></TableCell>
                  <TableCell>{f.status !== "paid" && <Button size="sm" onClick={() => markPaid(f.id)}>Collect</Button>}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
function ExamsTab() {
  const [db, setDB] = useDB();
  const [name, setName] = useState("");
  const [type, setType] = useState("Monthly");
  const [classId, setClassId] = useState(db.classes[0]?.id ?? "");
  const [date, setDate] = useState(new Date().toISOString().slice(0,10));
  const add = () => { if (!name) return; setDB(d => ({...d, exams: [{ id: uid("e"), name, type, classId, date }, ...d.exams]})); toast.success("Exam scheduled"); setName(""); };
  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <Card className="p-4 space-y-3">
        <h3 className="font-semibold">Schedule New Exam</h3>
        <div><Label>Name</Label><Input value={name} onChange={e => setName(e.target.value)} /></div>
        <div className="grid grid-cols-3 gap-2">
          <div><Label>Type</Label><Select value={type} onValueChange={setType}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{["Monthly","Midterm","Final","Practical","Online"].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Class</Label><Select value={classId} onValueChange={setClassId}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{db.classes.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Date</Label><Input type="date" value={date} onChange={e => setDate(e.target.value)} /></div>
        </div>
        <Button onClick={add}>Add Exam</Button>
      </Card>
      <Card className="p-4">
        <h3 className="font-semibold mb-3">Scheduled Exams</h3>
        <Table>
          <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Type</TableHead><TableHead>Class</TableHead><TableHead>Date</TableHead></TableRow></TableHeader>
          <TableBody>{db.exams.map(e => <TableRow key={e.id}><TableCell>{e.name}</TableCell><TableCell><Badge variant="outline">{e.type}</Badge></TableCell><TableCell>{db.classes.find(c => c.id === e.classId)?.name}</TableCell><TableCell>{e.date}</TableCell></TableRow>)}</TableBody>
        </Table>
      </Card>
    </div>
  );
}
function AttendanceTab() {
  const [db] = useDB();
  const summary = db.classes.map(c => {
    const sIds = new Set(db.students.filter(s => s.classId === c.id).map(s => s.id));
    const att = db.attendance.filter(a => sIds.has(a.studentId));
    const present = att.filter(a => a.status === "present").length;
    return { name: c.name, total: att.length, present, pct: att.length ? Math.round(present/att.length*100) : 0 };
  });
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-3">Attendance Monitoring</h3>
      <Table>
        <TableHeader><TableRow><TableHead>Class</TableHead><TableHead>Total Marks</TableHead><TableHead>Present</TableHead><TableHead>Rate</TableHead></TableRow></TableHeader>
        <TableBody>
          {summary.map((s,i) => <TableRow key={i}><TableCell>{s.name}</TableCell><TableCell>{s.total}</TableCell><TableCell>{s.present}</TableCell><TableCell><Badge variant={s.pct > 75 ? "default" : "destructive"}>{s.pct}%</Badge></TableCell></TableRow>)}
        </TableBody>
      </Table>
    </Card>
  );
}

function TimetableTab() {
  const [db] = useDB();
  const [classId, setClassId] = useState(db.classes[0]?.id ?? "");
  const days = ["Mon","Tue","Wed","Thu","Fri","Sat"];
  return (
    <Card className="p-4">
      <div className="flex gap-3 mb-3 items-end">
        <div><Label>Class</Label><Select value={classId} onValueChange={setClassId}><SelectTrigger className="w-44"><SelectValue /></SelectTrigger><SelectContent>{db.classes.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select></div>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>Day</TableHead>{[1,2,3,4,5].map(p => <TableHead key={p}>Period {p}</TableHead>)}</TableRow></TableHeader>
        <TableBody>
          {days.map(d => (
            <TableRow key={d}>
              <TableCell className="font-medium">{d}</TableCell>
              {[1,2,3,4,5].map(p => {
                const e = db.timetable.find(t => t.classId === classId && t.day === d && t.period === p);
                const sub = e ? db.subjects.find(s => s.id === e.subjectId)?.name : "—";
                const teacher = e ? db.teachers.find(t => t.id === e.teacherId)?.name : "";
                return <TableCell key={p} className="text-xs"><div className="font-medium">{sub}</div><div className="text-muted-foreground">{teacher}</div></TableCell>;
              })}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
}
function HomeworkTab() {
  const [db] = useDB();
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-3">All Homework Assignments</h3>
      <Table>
        <TableHeader><TableRow><TableHead>Title</TableHead><TableHead>Class</TableHead><TableHead>Subject</TableHead><TableHead>Teacher</TableHead><TableHead>Due</TableHead></TableRow></TableHeader>
        <TableBody>
          {db.homework.map(h => <TableRow key={h.id}><TableCell>{h.title}</TableCell><TableCell>{db.classes.find(c => c.id === h.classId)?.name}</TableCell><TableCell>{db.subjects.find(s => s.id === h.subjectId)?.name}</TableCell><TableCell>{db.teachers.find(t => t.id === h.teacherId)?.name}</TableCell><TableCell>{h.dueDate}</TableCell></TableRow>)}
        </TableBody>
      </Table>
    </Card>
  );
}

function LibraryTab() {
  const [db, setDB] = useDB();
  const issue = (bookId: string) => {
    setDB(d => {
      const book = d.books.find(b => b.id === bookId);
      if (!book || book.available <= 0) { toast.error("Not available"); return d; }
      return {
        ...d,
        books: d.books.map(b => b.id === bookId ? { ...b, available: b.available - 1 } : b),
        bookIssues: [{ id: uid("bi"), bookId, studentId: d.students[0].id, issueDate: new Date().toISOString().slice(0,10), dueDate: new Date(Date.now() + 14*864e5).toISOString().slice(0,10), fine: 0 }, ...d.bookIssues],
      };
    });
    toast.success("Book issued");
  };
  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <Card className="p-4">
        <h3 className="font-semibold mb-3">Books Inventory ({db.books.length})</h3>
        <Table>
          <TableHeader><TableRow><TableHead>Title</TableHead><TableHead>Author</TableHead><TableHead>Avail</TableHead><TableHead></TableHead></TableRow></TableHeader>
          <TableBody>{db.books.map(b => <TableRow key={b.id}><TableCell>{b.title}</TableCell><TableCell>{b.author}</TableCell><TableCell><Badge variant={b.available > 0 ? "default" : "destructive"}>{b.available}/{b.copies}</Badge></TableCell><TableCell><Button size="sm" onClick={() => issue(b.id)}>Issue</Button></TableCell></TableRow>)}</TableBody>
        </Table>
      </Card>
      <Card className="p-4">
        <h3 className="font-semibold mb-3">Issued Books</h3>
        <Table>
          <TableHeader><TableRow><TableHead>Book</TableHead><TableHead>Student</TableHead><TableHead>Due</TableHead><TableHead>Fine</TableHead></TableRow></TableHeader>
          <TableBody>{db.bookIssues.map(bi => <TableRow key={bi.id}><TableCell>{db.books.find(b => b.id === bi.bookId)?.title}</TableCell><TableCell>{db.students.find(s => s.id === bi.studentId)?.name}</TableCell><TableCell>{bi.dueDate}</TableCell><TableCell>AFN {bi.fine}</TableCell></TableRow>)}</TableBody>
        </Table>
      </Card>
    </div>
  );
}
function SalariesTab() {
  const [db, setDB] = useDB();
  const pay = (id: string) => { setDB(d => ({...d, salaries: d.salaries.map(s => s.id === id ? {...s, status: "paid", paidDate: new Date().toISOString().slice(0,10)} : s)})); toast.success("Salary paid"); };
  return (
    <Card className="p-4">
      <div className="flex justify-between mb-3"><h3 className="font-semibold">Salary Records</h3><Button size="sm" variant="outline" onClick={() => exportCSV("salaries.csv", db.salaries)}><Download className="size-4 mr-1" />Export</Button></div>
      <Table>
        <TableHeader><TableRow><TableHead>Teacher</TableHead><TableHead>Month</TableHead><TableHead>Amount</TableHead><TableHead>Status</TableHead><TableHead></TableHead></TableRow></TableHeader>
        <TableBody>
          {db.salaries.map(s => {
            const t = db.teachers.find(x => x.id === s.teacherId);
            return <TableRow key={s.id}><TableCell>{t?.name}</TableCell><TableCell>{s.month}</TableCell><TableCell>AFN {s.amount.toLocaleString()}</TableCell><TableCell><Badge variant={s.status === "paid" ? "default" : "destructive"}>{s.status}</Badge></TableCell><TableCell>{s.status !== "paid" && <Button size="sm" onClick={() => pay(s.id)}>Pay</Button>}</TableCell></TableRow>;
          })}
        </TableBody>
      </Table>
    </Card>
  );
}

function AccountingTab() {
  const [db] = useDB();
  const income = db.transactions.filter(t => t.type === "income").reduce((s,t) => s+t.amount, 0);
  const expense = db.transactions.filter(t => t.type === "expense").reduce((s,t) => s+t.amount, 0);
  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-3 gap-4">
        <StatCard label="Total Income" value={`AFN ${income.toLocaleString()}`} icon={DollarSign} color="success" />
        <StatCard label="Total Expense" value={`AFN ${expense.toLocaleString()}`} icon={Wallet} color="destructive" />
        <StatCard label="Net Profit" value={`AFN ${(income-expense).toLocaleString()}`} icon={Activity} color={income > expense ? "success" : "destructive"} />
      </div>
      <Card className="p-4">
        <h3 className="font-semibold mb-3">Transactions</h3>
        <Table>
          <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Type</TableHead><TableHead>Category</TableHead><TableHead>Description</TableHead><TableHead>Amount</TableHead></TableRow></TableHeader>
          <TableBody>{db.transactions.map(t => <TableRow key={t.id}><TableCell>{t.date}</TableCell><TableCell><Badge variant={t.type === "income" ? "default" : "destructive"}>{t.type}</Badge></TableCell><TableCell>{t.category}</TableCell><TableCell>{t.description}</TableCell><TableCell className={t.type === "income" ? "text-success" : "text-destructive"}>AFN {t.amount.toLocaleString()}</TableCell></TableRow>)}</TableBody>
        </Table>
      </Card>
    </div>
  );
}
function AuditTab() {
  const [db] = useDB();
  return (
    <Card className="p-4">
      <div className="flex justify-between mb-3"><h3 className="font-semibold">Audit Logs</h3><Button size="sm" variant="outline" onClick={() => exportCSV("audit.csv", db.auditLogs)}><Download className="size-4 mr-1" />Export</Button></div>
      <Table>
        <TableHeader><TableRow><TableHead>Timestamp</TableHead><TableHead>User</TableHead><TableHead>Action</TableHead><TableHead>Detail</TableHead><TableHead>IP</TableHead></TableRow></TableHeader>
        <TableBody>{db.auditLogs.map(l => <TableRow key={l.id}><TableCell className="text-xs">{new Date(l.timestamp).toLocaleString()}</TableCell><TableCell>{l.user}</TableCell><TableCell><Badge variant="outline">{l.action}</Badge></TableCell><TableCell className="text-xs">{l.detail}</TableCell><TableCell className="text-xs text-muted-foreground">{l.ip}</TableCell></TableRow>)}</TableBody>
      </Table>
    </Card>
  );
}

function NotificationsTab() {
  const [db, setDB] = useDB();
  const [title, setTitle] = useState("");
  const [msg, setMsg] = useState("");
  const [channel, setChannel] = useState<"in-app"|"sms"|"email"|"whatsapp">("in-app");
  const send = () => {
    if (!title) return;
    setDB(d => ({...d, notifications: [{ id: uid("n"), title, message: msg, type: "info", date: new Date().toISOString(), read: false, channel }, ...d.notifications]}));
    toast.success(`Notification sent via ${channel}`); setTitle(""); setMsg("");
  };
  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <Card className="p-4 space-y-3">
        <h3 className="font-semibold">Broadcast Notification</h3>
        <div><Label>Title</Label><Input value={title} onChange={e => setTitle(e.target.value)} /></div>
        <div><Label>Message</Label><Input value={msg} onChange={e => setMsg(e.target.value)} /></div>
        <div><Label>Channel</Label><Select value={channel} onValueChange={v => setChannel(v as typeof channel)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{["in-app","sms","email","whatsapp"].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select></div>
        <Button onClick={send}>Send</Button>
      </Card>
      <Card className="p-4">
        <h3 className="font-semibold mb-3">Recent</h3>
        <div className="space-y-2 max-h-96 overflow-y-auto">{db.notifications.map(n => <div key={n.id} className="p-3 border rounded-lg"><div className="flex justify-between"><div className="font-medium text-sm">{n.title}</div><Badge variant="outline">{n.channel}</Badge></div><div className="text-xs text-muted-foreground">{n.message}</div></div>)}</div>
      </Card>
    </div>
  );
}
function IdCardsTab() {
  const [db] = useDB();
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
      {db.students.slice(0, 9).map(s => {
        const c = db.classes.find(x => x.id === s.classId);
        return (
          <Card key={s.id} className="p-0 overflow-hidden">
            <div className="bg-gradient-to-r from-primary to-accent p-3 text-primary-foreground text-center">
              <div className="text-xs opacity-80">NOOR ACADEMY</div>
              <div className="font-bold">STUDENT ID CARD</div>
            </div>
            <div className="p-4 flex gap-3 items-center">
              <div className="size-16 rounded-full bg-muted flex items-center justify-center text-xl font-bold">{s.name.charAt(0)}</div>
              <div className="flex-1 text-xs space-y-0.5">
                <div className="font-bold text-base">{s.name}</div>
                <div>Roll: <b>{s.rollNo}</b></div>
                <div>Class: <b>{c?.name} {c?.section}</b></div>
                <div className="text-muted-foreground">Valid: 2026-2027</div>
              </div>
              <div className="size-12 bg-foreground/10 rounded flex items-center justify-center text-[8px] text-center">QR<br/>CODE</div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}

function CertificatesTab() {
  const [db] = useDB();
  const issue = (sid: string, type: string) => {
    const s = db.students.find(x => x.id === sid);
    if (!s) return;
    downloadText(`${type}-${s.rollNo}.txt`, `NOOR ACADEMY\n\n${type.toUpperCase()}\n\nThis is to certify that ${s.name} (Roll ${s.rollNo}) has earned this ${type}.\n\nIssued: ${new Date().toLocaleDateString()}\n\nPrincipal Signature\n___________________`);
    toast.success(`${type} issued for ${s.name}`);
  };
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-3">Issue Certificates</h3>
      <Table>
        <TableHeader><TableRow><TableHead>Student</TableHead><TableHead>Class</TableHead><TableHead>Issue</TableHead></TableRow></TableHeader>
        <TableBody>{db.students.slice(0,12).map(s => <TableRow key={s.id}><TableCell>{s.name}</TableCell><TableCell>{db.classes.find(c => c.id === s.classId)?.name}</TableCell><TableCell className="space-x-1"><Button size="sm" variant="outline" onClick={() => issue(s.id, "Character Certificate")}>Character</Button><Button size="sm" variant="outline" onClick={() => issue(s.id, "Completion Certificate")}>Completion</Button><Button size="sm" variant="outline" onClick={() => issue(s.id, "Achievement Award")}>Achievement</Button></TableCell></TableRow>)}</TableBody>
      </Table>
    </Card>
  );
}
function SettingsTab() {
  const [db, setDB] = useDB();
  const backup = () => {
    downloadText(`backup-${new Date().toISOString().slice(0,10)}.json`, JSON.stringify(db, null, 2), "application/json");
    toast.success("Backup downloaded");
  };
  const reset = () => { localStorage.removeItem("sms_db_v1"); window.location.reload(); };
  const restore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    file.text().then(text => {
      try { const parsed = JSON.parse(text); setDB(() => parsed); toast.success("Restored from backup"); }
      catch { toast.error("Invalid backup file"); }
    });
  };
  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <Card className="p-5 space-y-3">
        <h3 className="font-semibold">System Settings</h3>
        <div><Label>School Name</Label><Input defaultValue="Noor Academy" /></div>
        <div><Label>Academic Year</Label><Input defaultValue="2026-2027" /></div>
        <div><Label>Currency</Label><Input defaultValue="AFN" /></div>
        <Button onClick={() => toast.success("Settings saved")}>Save</Button>
      </Card>
      <Card className="p-5 space-y-3">
        <h3 className="font-semibold">Backup & Restore</h3>
        <p className="text-sm text-muted-foreground">Download a full backup or restore from a previous backup file.</p>
        <div className="flex gap-2 flex-wrap">
          <Button onClick={backup}><Database className="size-4 mr-1" />Download Backup</Button>
          <Button variant="outline" asChild><label className="cursor-pointer">Restore<input type="file" accept=".json" className="hidden" onChange={restore} /></label></Button>
          <Button variant="destructive" onClick={reset}>Reset Demo Data</Button>
        </div>
      </Card>
      <Card className="p-5 space-y-3 lg:col-span-2">
        <h3 className="font-semibold">Roles & Permissions</h3>
        <Table>
          <TableHeader><TableRow><TableHead>Role</TableHead><TableHead>Permissions</TableHead></TableRow></TableHeader>
          <TableBody>
            <TableRow><TableCell><Badge>Admin</Badge></TableCell><TableCell>Full system access</TableCell></TableRow>
            <TableRow><TableCell><Badge variant="secondary">Teacher</Badge></TableCell><TableCell>Attendance + Marks + Homework (no delete, no settings, no financials)</TableCell></TableRow>
            <TableRow><TableCell><Badge variant="secondary">Student</Badge></TableCell><TableCell>View own data only</TableCell></TableRow>
            <TableRow><TableCell><Badge variant="secondary">Parent</Badge></TableCell><TableCell>View child data only</TableCell></TableRow>
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
function DashboardTab() {
  const [db] = useDB();
  const totalStudents = db.students.length;
  const totalTeachers = db.teachers.length;
  const totalRevenue = db.transactions.filter(t => t.type === "income").reduce((s,t) => s+t.amount, 0);
  const totalExpense = db.transactions.filter(t => t.type === "expense").reduce((s,t) => s+t.amount, 0);
  const dueFees = db.fees.filter(f => f.status !== "paid").reduce((s,f) => s+f.amount, 0);
  const attRows = (() => {
    const map = new Map<string, { date: string; present: number; absent: number }>();
    db.attendance.forEach(a => {
      const r = map.get(a.date) ?? { date: a.date, present: 0, absent: 0 };
      if (a.status === "present") r.present++; else if (a.status === "absent") r.absent++;
      map.set(a.date, r);
    });
    return Array.from(map.values()).sort((a,b) => a.date.localeCompare(b.date)).slice(-7);
  })();
  const classDist = db.classes.map(c => ({ name: c.name, value: db.students.filter(s => s.classId === c.id).length }));
  const COLORS = ["oklch(0.52 0.18 255)","oklch(0.7 0.16 180)","oklch(0.65 0.17 150)","oklch(0.75 0.16 75)"];

  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-4 gap-4">
        <StatCard label="Students" value={totalStudents} icon={Users} color="primary" hint="Active enrollment" />
        <StatCard label="Teachers" value={totalTeachers} icon={GraduationCap} color="accent" />
        <StatCard label="Revenue" value={`AFN ${(totalRevenue/1000).toFixed(0)}K`} icon={DollarSign} color="success" hint={`Expense: AFN ${(totalExpense/1000).toFixed(0)}K`} />
        <StatCard label="Fees Due" value={`AFN ${(dueFees/1000).toFixed(0)}K`} icon={Wallet} color="warning" />
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-4">
          <h3 className="font-semibold mb-2">Attendance — Last 7 Days</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={attRows}><XAxis dataKey="date" tick={{ fontSize: 10 }} /><YAxis tick={{ fontSize: 10 }} /><Tooltip /><Bar dataKey="present" fill="oklch(0.65 0.17 150)" /><Bar dataKey="absent" fill="oklch(0.6 0.22 25)" /></BarChart>
          </ResponsiveContainer>
        </Card>
        <Card className="p-4">
          <h3 className="font-semibold mb-2">Class Distribution</h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart><Pie data={classDist} dataKey="value" nameKey="name" label>{classDist.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /></PieChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
}
function ParentsTab() {
  const [db] = useDB();
  const parents = Array.from(new Map(db.students.map(s => [s.parentPhone, { name: s.parentName, phone: s.parentPhone, child: s.name }])).values());
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold">Parents Directory ({parents.length})</h3>
        <Button size="sm" variant="outline" onClick={() => exportCSV("parents.csv", parents)}><Download className="size-4 mr-1" />Export</Button>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>Parent</TableHead><TableHead>Phone</TableHead><TableHead>Child</TableHead></TableRow></TableHeader>
        <TableBody>
          {parents.map((p, i) => <TableRow key={i}><TableCell>{p.name}</TableCell><TableCell>{p.phone}</TableCell><TableCell>{p.child}</TableCell></TableRow>)}
        </TableBody>
      </Table>
    </Card>
  );
}